<template>
  <div class="card-dark">
    <div class="header-con-navegacion">
      <button @click="volverAEmpresas" class="btn-volver">
        <i class="ph ph-arrow-left"></i>
        <span>Volver a Empresas</span>
      </button>
      <h2 class="text-xl font-bold text-white">
        Cuaderno de Analista de Incidentes
        <span v-if="empresaInfo.nombre" class="empresa-info-header">
          - {{ empresaInfo.nombre }} ({{ empresaInfo.tipo === 'OIV' ? 'Operador de Infraestructura Vital' : 'Proveedor de Servicios Esenciales' }})
        </span>
      </h2>
      <button @click="guardarIncidente" :disabled="!esValido || guardando" class="btn btn-primary ml-auto">
        <i v-if="guardando" class="ph ph-spinner-gap" :class="{'animate-spin': guardando}"></i>
        <i v-else class="ph ph-floppy-disk"></i>
        {{ guardando ? 'Guardando...' : 'Guardar Incidente' }}
      </button>
    </div>

    <div v-if="loading" class="text-center p-8 text-gray-400">Cargando datos del incidente...</div>
    <div v-else-if="error" class="error-banner"><strong>Error:</strong> {{ error }}</div>
    
    <div v-else class="mt-6 space-y-2">
      <!-- 1. Identificación General -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('identificacion')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('identificacion')"
        >
          <span class="header-text">
            <i class="ph ph-identification-badge accordion-icon"></i>
            <span class="section-title-accordion">1. Identificación General</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('identificacion') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('identificacion')" class="accordion-content">
            <div class="content-section">
              <div class="form-grid">
                <div>
                  <label class="form-label">Tipo de Registro del Incidente</label>
                  <select v-model="datos.tipoFlujo" class="form-input">
                    <option value="Informativo">Informativo (Registro simple)</option>
                    <option value="Interno">Interno</option>
                  </select>
                </div>
                <div>
                  <label class="form-label">Título del Incidente *</label>
                  <input v-model="datos.titulo" type="text" class="form-input" 
                         placeholder="Descripción breve del incidente">
                </div>
                <div>
                  <label class="form-label">Fecha y Hora de Detección *</label>
                  <input v-model="datos.fechaDeteccion" type="datetime-local" class="form-input">
                </div>
                <div>
                  <label class="form-label">Fecha y Hora de Ocurrencia</label>
                  <input v-model="datos.fechaOcurrencia" type="datetime-local" class="form-input">
                  <small class="text-gray-400">Solo si difiere de la fecha de detección</small>
                </div>
                <div>
                  <label class="form-label">Criticidad *</label>
                  <select v-model="datos.criticidad" class="form-input">
                    <option value="Baja">Baja</option>
                    <option value="Media">Media</option>
                    <option value="Alta">Alta</option>
                    <option value="Crítica">Crítica</option>
                  </select>
                </div>
                <div>
                  <label class="form-label">Alcance Geográfico</label>
                  <select v-model="datos.alcanceGeografico" class="form-input">
                    <option value="Local">Local</option>
                    <option value="Regional">Regional</option>
                    <option value="Nacional">Nacional</option>
                    <option value="Internacional">Internacional</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 2. Descripción y Alcance -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('descripcion')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('descripcion')"
        >
          <span class="header-text">
            <i class="ph ph-file-text accordion-icon"></i>
            <span class="section-title-accordion">2. Descripción y Alcance</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('descripcion') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('descripcion')" class="accordion-content">
            <div class="content-section">
              <h3 class="section-title">Descripción del Incidente</h3>
              <div class="campo-formulario">
                <label class="form-label">Descripción Inicial Detallada *</label>
                <textarea v-model="datos.descripcionInicial" class="form-input" rows="4"
                          placeholder="Describa detalladamente el incidente..."></textarea>
              </div>
            </div>

            <div class="content-section">
              <h3 class="section-title">Impacto y Afectación</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="form-label">Impacto Preliminar Observado</label>
                  <textarea v-model="datos.impactoPreliminar" class="form-input" rows="3"
                            placeholder="Describa el impacto inicial observado..."></textarea>
                </div>
                <div>
                  <label class="form-label">Sistemas, Activos o Personal Afectado *</label>
                  <textarea v-model="datos.sistemasAfectados" class="form-input" rows="3"
                            placeholder="Especifique sistemas afectados..."></textarea>
                </div>
                <div>
                  <label class="form-label">Servicios Interrumpidos y Duración</label>
                  <input v-model="datos.serviciosInterrumpidos" type="text" class="form-input"
                         placeholder="Servicios afectados y tiempo de indisponibilidad">
                </div>
              </div>
            </div>

            <!-- Sección de Evidencias -->
            <div class="content-section evidencias-full-width">
              <div class="evidencias-box">
                <div class="evidencias-header">
                  <div style="display: flex; align-items: center; justify-content: space-between;">
                    <h3>
                      <i class="ph ph-folder-open" style="color: #60a5fa;"></i>
                      Evidencias - Descripción
                    </h3>
                    <div class="evidencias-stats" v-if="getEvidencias('descripcion').length > 0">
                      <span class="stat-badge vigente">✓ {{ getEvidencias('descripcion').length }}</span>
                    </div>
                    <div v-else style="font-size: 0.75rem; color: #9ca3af;">Sin evidencias</div>
                  </div>
                </div>

                <div class="evidencias-list" v-if="getEvidencias('descripcion').length > 0">
                  <div v-for="(archivo, index) in getEvidencias('descripcion')" 
                       :key="index" class="evidencia-item">
                    <div class="evidencia-content" @click="verEvidencia(archivo)">
                      <div class="evidencia-info">
                        <i :class="getIconoArchivo(archivo.nombre)" class="evidencia-icon"></i>
                        <div class="evidencia-details">
                          <div class="evidencia-name-line">
                            <span class="evidencia-name">{{ archivo.nombre }}</span>
                            <span class="evidencia-version">{{ archivo.fechaSubida || 'Ahora' }}</span>
                            <span v-if="archivo.descripcion" class="evidencia-comentario">"{{ archivo.descripcion }}"</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="evidencia-actions">
                      <button @click.stop="editarEvidencia(archivo, 'descripcion')"
                              class="btn-editar-evidencia" title="Editar comentario">
                        <i class="ph ph-pencil"></i>
                      </button>
                      <button @click.stop="eliminarEvidencia('descripcion', index)"
                              class="btn-eliminar-evidencia" title="Eliminar evidencia">
                        <i class="ph ph-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div v-else class="evidencias-empty">No hay evidencias cargadas</div>

                <div class="evidencias-footer" v-if="getEvidencias('descripcion').length === 0">
                  <button @click="abrirModalEvidencias('descripcion')">
                    Subir primera evidencia →
                  </button>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button @click="abrirModalEvidencias('descripcion')" class="btn btn-secondary">
                <i class="ph ph-paperclip"></i> Gestionar Evidencias
              </button>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 3. Análisis Preliminar -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('analisis')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('analisis')"
        >
          <span class="header-text">
            <i class="ph ph-magnifying-glass-plus accordion-icon"></i>
            <span class="section-title-accordion">3. Análisis Preliminar</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('analisis') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('analisis')" class="accordion-content">
            <div class="content-section">
              <h3 class="section-title">Análisis Técnico del Incidente</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="form-label">Tipo de Amenaza Probable</label>
                  <input v-model="datos.tipoAmenaza" type="text" class="form-input"
                         placeholder="Ej: Malware, Phishing, DDoS, etc.">
                </div>
                <div>
                  <label class="form-label">Origen / Vector de Ataque Probable *</label>
                  <input v-model="datos.vectorAtaque" type="text" class="form-input"
                         placeholder="Ej: Externo / Fuerza bruta desde IP 192.168.1.100">
                </div>
                <div>
                  <label class="form-label">Responsable del Cliente</label>
                  <input v-model="datos.responsableCliente" type="text" class="form-input"
                         placeholder="Persona responsable por parte del cliente">
                </div>
              </div>
            </div>

            <!-- Sección de Evidencias -->
            <div class="content-section evidencias-full-width">
              <div class="evidencias-box">
                <div class="evidencias-header">
                  <div style="display: flex; align-items: center; justify-content: space-between;">
                    <h3>
                      <i class="ph ph-folder-open" style="color: #60a5fa;"></i>
                      Evidencias - Análisis
                    </h3>
                    <div class="evidencias-stats" v-if="getEvidencias('analisis').length > 0">
                      <span class="stat-badge vigente">✓ {{ getEvidencias('analisis').length }}</span>
                    </div>
                    <div v-else style="font-size: 0.75rem; color: #9ca3af;">Sin evidencias</div>
                  </div>
                </div>

                <div class="evidencias-list" v-if="getEvidencias('analisis').length > 0">
                  <div v-for="(archivo, index) in getEvidencias('analisis')" 
                       :key="index" class="evidencia-item">
                    <div class="evidencia-content" @click="verEvidencia(archivo)">
                      <div class="evidencia-info">
                        <i :class="getIconoArchivo(archivo.nombre)" class="evidencia-icon"></i>
                        <div class="evidencia-details">
                          <div class="evidencia-name-line">
                            <span class="evidencia-name">{{ archivo.nombre }}</span>
                            <span class="evidencia-version">{{ archivo.fechaSubida || 'Ahora' }}</span>
                            <span v-if="archivo.descripcion" class="evidencia-comentario">"{{ archivo.descripcion }}"</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="evidencia-actions">
                      <button @click.stop="editarEvidencia(archivo, 'analisis')"
                              class="btn-editar-evidencia" title="Editar comentario">
                        <i class="ph ph-pencil"></i>
                      </button>
                      <button @click.stop="eliminarEvidencia('analisis', index)"
                              class="btn-eliminar-evidencia" title="Eliminar evidencia">
                        <i class="ph ph-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div v-else class="evidencias-empty">No hay evidencias cargadas</div>

                <div class="evidencias-footer" v-if="getEvidencias('analisis').length === 0">
                  <button @click="abrirModalEvidencias('analisis')">
                    Subir primera evidencia →
                  </button>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button @click="abrirModalEvidencias('analisis')" class="btn btn-secondary">
                <i class="ph ph-paperclip"></i> Gestionar Evidencias
              </button>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 4. Clasificación de Taxonomías -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('clasificacion')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('clasificacion')"
        >
          <span class="header-text">
            <i class="ph ph-tag accordion-icon"></i>
            <span class="section-title-accordion">4. Clasificación de Taxonomías</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('clasificacion') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('clasificacion')" class="accordion-content">
            <div class="content-section">
              <div class="flex flex-col sm:flex-row sm:items-center gap-4">
                <div class="flex-grow">
                  <label for="taxonomia-select" class="form-label">Seleccione una taxonomía para gestionar</label>
                  <select v-model="taxonomiaSeleccionada" @change="agregarTaxonomia" 
                          class="form-input" id="taxonomia-select">
                    <option value="">-- Seleccione una taxonomía --</option>
                    <option v-for="tax in taxonomiasDisponibles" :key="tax.Id_Taxonomia" 
                            :value="tax.Id_Taxonomia" :disabled="estaSeleccionada(tax.Id_Taxonomia)">
                      {{ tax.Nombre }} {{ estaSeleccionada(tax.Id_Taxonomia) ? '(Ya agregada)' : '' }}
                    </option>
                  </select>
                </div>
              </div>
            </div>

            <div v-if="datos.taxonomiasSeleccionadas.length > 0" class="content-section">
              <h4 class="form-label mb-3">Taxonomías seleccionadas ({{ datos.taxonomiasSeleccionadas.length }})</h4>
              <div class="taxonomias-chips">
                <div v-for="(tax, index) in datos.taxonomiasSeleccionadas" 
                     :key="tax.id" class="taxonomy-chip" 
                     :class="{ active: taxonomiaActiva === tax.id }"
                     @click="seleccionarTaxonomia(tax.id)">
                  <span>{{ tax.nombre }}</span>
                  <button @click.stop="removerTaxonomia(index)" class="chip-remove">
                    <i class="ph ph-x"></i>
                  </button>
                </div>
              </div>
            </div>

            <div v-if="taxonomiaActiva" class="content-section">
              <h3 class="section-title">Detalle de la Taxonomía</h3>
              <div class="taxonomia-detalle">
                <div class="taxonomia-campo">
                  <span class="taxonomia-label">Área:</span>
                  <span class="taxonomia-valor">{{ getTaxonomiaSeleccionada()?.Area || 'Sin área' }}</span>
                </div>
                <div class="taxonomia-campo">
                  <span class="taxonomia-label">Efecto:</span>
                  <span class="taxonomia-valor">{{ getTaxonomiaSeleccionada()?.Efecto || 'Sin efecto' }}</span>
                </div>
                <div class="taxonomia-campo">
                  <span class="taxonomia-label">Categoría:</span>
                  <span class="taxonomia-valor">{{ getTaxonomiaSeleccionada()?.Categoria_del_Incidente || 'Sin categoría' }}</span>
                </div>
                <div class="taxonomia-campo">
                  <span class="taxonomia-label">Subcategoría:</span>
                  <span class="taxonomia-valor">{{ getTaxonomiaSeleccionada()?.Subcategoria_del_Incidente || 'Sin subcategoría' }}</span>
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div>
                  <label class="form-label">Observaciones Técnicas</label>
                  <textarea v-model="getTaxonomiaData(taxonomiaActiva).observacionesTecnicas" 
                            class="form-input" rows="3"
                            placeholder="Describa las observaciones técnicas sobre esta taxonomía..."></textarea>
                </div>
                <div>
                  <label class="form-label">Observaciones de Impacto</label>
                  <textarea v-model="getTaxonomiaData(taxonomiaActiva).observacionesImpacto" 
                            class="form-input" rows="3"
                            placeholder="Describa el impacto de esta taxonomía en el incidente..."></textarea>
                </div>
              </div>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 5. Acciones Inmediatas -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('acciones')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('acciones')"
        >
          <span class="header-text">
            <i class="ph ph-lightning accordion-icon"></i>
            <span class="section-title-accordion">5. Acciones Inmediatas (Requerido para OIV/PSE)</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('acciones') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('acciones')" class="accordion-content">
            <div class="content-section">
              <h3 class="section-title">Medidas de Contención y Respuesta</h3>
              <div class="campo-formulario">
                <label class="form-label">Medidas de Contención Iniciales *</label>
                <textarea v-model="datos.medidasContencion" class="form-input" rows="4"
                          placeholder="Describa las acciones inmediatas tomadas para contener el incidente..."></textarea>
              </div>
            </div>

            <!-- Sección de Evidencias -->
            <div class="content-section evidencias-full-width">
              <div class="evidencias-box">
                <div class="evidencias-header">
                  <div style="display: flex; align-items: center; justify-content: space-between;">
                    <h3>
                      <i class="ph ph-folder-open" style="color: #60a5fa;"></i>
                      Evidencias - Acciones
                    </h3>
                    <div class="evidencias-stats" v-if="getEvidencias('acciones').length > 0">
                      <span class="stat-badge vigente">✓ {{ getEvidencias('acciones').length }}</span>
                    </div>
                    <div v-else style="font-size: 0.75rem; color: #9ca3af;">Sin evidencias</div>
                  </div>
                </div>

                <div class="evidencias-list" v-if="getEvidencias('acciones').length > 0">
                  <div v-for="(archivo, index) in getEvidencias('acciones')" 
                       :key="index" class="evidencia-item">
                    <div class="evidencia-content" @click="verEvidencia(archivo)">
                      <div class="evidencia-info">
                        <i :class="getIconoArchivo(archivo.nombre)" class="evidencia-icon"></i>
                        <div class="evidencia-details">
                          <div class="evidencia-name-line">
                            <span class="evidencia-name">{{ archivo.nombre }}</span>
                            <span class="evidencia-version">{{ archivo.fechaSubida || 'Ahora' }}</span>
                            <span v-if="archivo.descripcion" class="evidencia-comentario">"{{ archivo.descripcion }}"</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="evidencia-actions">
                      <button @click.stop="editarEvidencia(archivo, 'acciones')"
                              class="btn-editar-evidencia" title="Editar comentario">
                        <i class="ph ph-pencil"></i>
                      </button>
                      <button @click.stop="eliminarEvidencia('acciones', index)"
                              class="btn-eliminar-evidencia" title="Eliminar evidencia">
                        <i class="ph ph-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div v-else class="evidencias-empty">No hay evidencias cargadas</div>

                <div class="evidencias-footer" v-if="getEvidencias('acciones').length === 0">
                  <button @click="abrirModalEvidencias('acciones')">
                    Subir primera evidencia →
                  </button>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button @click="abrirModalEvidencias('acciones')" class="btn btn-secondary">
                <i class="ph ph-paperclip"></i> Gestionar Evidencias
              </button>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 6. Análisis Final y Mejoras -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('analisis-final')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('analisis-final')"
        >
          <span class="header-text">
            <i class="ph ph-clipboard-text accordion-icon"></i>
            <span class="section-title-accordion">6. Análisis Final y Mejoras</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('analisis-final') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('analisis-final')" class="accordion-content">
            <div class="content-section">
              <h3 class="section-title">Análisis de Causa Raíz</h3>
              <div class="campo-formulario">
                <label class="form-label">Análisis de Causa Raíz (OIV/PSE)</label>
                <textarea v-model="datos.analisisCausaRaiz" class="form-input" rows="4"
                          placeholder="Análisis detallado de las causas fundamentales del incidente..."></textarea>
              </div>
            </div>

            <div class="content-section">
              <h3 class="section-title">Lecciones Aprendidas y Mejoras</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="form-label">Lecciones Aprendidas</label>
                  <textarea v-model="datos.leccionesAprendidas" class="form-input" rows="3"
                            placeholder="Principales aprendizajes del incidente..."></textarea>
                </div>
                <div>
                  <label class="form-label">Recomendaciones de Mejora</label>
                  <textarea v-model="datos.recomendacionesMejora" class="form-input" rows="3"
                            placeholder="Mejoras propuestas para prevenir futuros incidentes..."></textarea>
                </div>
              </div>
            </div>

            <!-- Sección de Evidencias -->
            <div class="content-section evidencias-full-width">
              <div class="evidencias-box">
                <div class="evidencias-header">
                  <div style="display: flex; align-items: center; justify-content: space-between;">
                    <h3>
                      <i class="ph ph-folder-open" style="color: #60a5fa;"></i>
                      Evidencias - Análisis Final
                    </h3>
                    <div class="evidencias-stats" v-if="getEvidencias('analisis-final').length > 0">
                      <span class="stat-badge vigente">✓ {{ getEvidencias('analisis-final').length }}</span>
                    </div>
                    <div v-else style="font-size: 0.75rem; color: #9ca3af;">Sin evidencias</div>
                  </div>
                </div>

                <div class="evidencias-list" v-if="getEvidencias('analisis-final').length > 0">
                  <div v-for="(archivo, index) in getEvidencias('analisis-final')" 
                       :key="index" class="evidencia-item">
                    <div class="evidencia-content" @click="verEvidencia(archivo)">
                      <div class="evidencia-info">
                        <i :class="getIconoArchivo(archivo.nombre)" class="evidencia-icon"></i>
                        <div class="evidencia-details">
                          <div class="evidencia-name-line">
                            <span class="evidencia-name">{{ archivo.nombre }}</span>
                            <span class="evidencia-version">{{ archivo.fechaSubida || 'Ahora' }}</span>
                            <span v-if="archivo.descripcion" class="evidencia-comentario">"{{ archivo.descripcion }}"</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="evidencia-actions">
                      <button @click.stop="editarEvidencia(archivo, 'analisis-final')"
                              class="btn-editar-evidencia" title="Editar comentario">
                        <i class="ph ph-pencil"></i>
                      </button>
                      <button @click.stop="eliminarEvidencia('analisis-final', index)"
                              class="btn-eliminar-evidencia" title="Eliminar evidencia">
                        <i class="ph ph-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div v-else class="evidencias-empty">No hay evidencias cargadas</div>

                <div class="evidencias-footer" v-if="getEvidencias('analisis-final').length === 0">
                  <button @click="abrirModalEvidencias('analisis-final')">
                    Subir primera evidencia →
                  </button>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button @click="abrirModalEvidencias('analisis-final')" class="btn btn-secondary">
                <i class="ph ph-paperclip"></i> Gestionar Evidencias
              </button>
            </div>
          </div>
        </Transition>
      </div>

      <!-- 7. Resumen de Archivos -->
      <div class="accordion-item">
        <button 
          @click="toggleAcordeon('resumen-archivos')" 
          class="accordion-header"
          :aria-expanded="acordeonesAbiertos.has('resumen-archivos')"
        >
          <span class="header-text">
            <i class="ph ph-folder-simple accordion-icon"></i>
            <span class="section-title-accordion">7. Resumen de Archivos</span>
          </span>
          <i class="ph ph-caret-down accordion-caret" :class="{ 'open': acordeonesAbiertos.has('resumen-archivos') }"></i>
        </button>
        
        <Transition name="accordion-fade">
          <div v-show="acordeonesAbiertos.has('resumen-archivos')" class="accordion-content">
            <div class="content-section">
              <h3 class="section-title">Resumen de Todos los Archivos del Incidente</h3>
              
              <div v-if="todosLosArchivos.length > 0" class="archivos-resumen-container">
                <div class="archivos-stats-global">
                  <div class="stat-item">
                    <i class="ph ph-files"></i>
                    <span>Total de archivos: {{ todosLosArchivos.length }}</span>
                  </div>
                </div>

                <table class="archivos-table">
                  <thead>
                    <tr>
                      <th>Archivo</th>
                      <th>Sección</th>
                      <th>Fecha</th>
                      <th>Descripción</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(archivo, index) in todosLosArchivos" :key="index">
                      <td>
                        <div class="archivo-info">
                          <i :class="getIconoArchivo(archivo.nombre)"></i>
                          <span>{{ archivo.nombre }}</span>
                        </div>
                      </td>
                      <td>{{ archivo.seccion }}</td>
                      <td>{{ archivo.fechaSubida || 'Ahora' }}</td>
                      <td>{{ archivo.descripcion || '-' }}</td>
                      <td>
                        <button @click="verEvidencia(archivo)" class="btn-action" title="Ver archivo">
                          <i class="ph ph-eye"></i>
                        </button>
                        <button @click="descargarArchivo(archivo)" class="btn-action" title="Descargar">
                          <i class="ph ph-download"></i>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div v-else class="evidencias-empty">
                No hay archivos cargados en ninguna sección del incidente
              </div>
            </div>
          </div>
        </Transition>
      </div>
    </div>
  </div>

  <!-- Modal de Gestión de Evidencias -->
  <div v-if="modalEvidencias.visible" class="modal-overlay" @click="cerrarModalEvidencias">
    <div class="modal-content" @click.stop>
      <div class="modal-header">
        <h3>Gestión de Evidencias - {{ getNombreSeccion(modalEvidencias.seccion) }}</h3>
        <button @click="cerrarModalEvidencias" class="btn-close">
          <i class="ph ph-x"></i>
        </button>
      </div>
      
      <div class="modal-body">
        <div class="upload-zone">
          <input 
            ref="fileInputModal" 
            type="file" 
            multiple 
            @change="handleFileUpload"
            style="display: none;"
          >
          <div class="upload-drop-zone" @click="$refs.fileInputModal.click()">
            <i class="ph ph-cloud-upload"></i>
            <p>Haz clic para subir archivos</p>
            <p class="text-sm">PDF, DOC, XLS, Imágenes, etc.</p>
          </div>
        </div>

        <div v-if="archivosTemporales.length > 0" class="archivos-temporales">
          <h4>Archivos por subir:</h4>
          <div v-for="(archivo, index) in archivosTemporales" :key="index" class="archivo-temporal">
            <div class="archivo-info">
              <i :class="getIconoArchivo(archivo.name)"></i>
              <span>{{ archivo.name }}</span>
            </div>
            <input 
              v-model="archivo.descripcion" 
              type="text" 
              placeholder="Descripción del archivo..."
              class="form-input"
            >
            <button @click="removerArchivoTemporal(index)" class="btn-remove">
              <i class="ph ph-trash"></i>
            </button>
          </div>
        </div>

        <div v-if="getEvidencias(modalEvidencias.seccion).length > 0" class="evidencias-existentes">
          <h4>Evidencias actuales:</h4>
          <div v-for="(archivo, index) in getEvidencias(modalEvidencias.seccion)" 
               :key="index" class="evidencia-item-modal">
            <div class="evidencia-info">
              <i :class="getIconoArchivo(archivo.nombre)"></i>
              <span>{{ archivo.nombre }}</span>
              <span class="evidencia-fecha">{{ archivo.fechaSubida || 'Ahora' }}</span>
            </div>
            <p v-if="archivo.descripcion" class="evidencia-descripcion">{{ archivo.descripcion }}</p>
            <button @click="eliminarEvidencia(modalEvidencias.seccion, index)" 
                    class="btn-eliminar">
              <i class="ph ph-trash"></i> Eliminar
            </button>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button @click="cerrarModalEvidencias" class="btn btn-secondary">Cancelar</button>
        <button @click="guardarEvidencias" class="btn btn-primary" 
                :disabled="archivosTemporales.length === 0">
          Guardar Evidencias
        </button>
      </div>
    </div>
  </div>

  <!-- Modal de Edición de Evidencia -->
  <div v-if="modalEdicion.visible" class="modal-overlay" @click="cerrarModalEdicion">
    <div class="modal-content modal-sm" @click.stop>
      <div class="modal-header">
        <h3>Editar Evidencia</h3>
        <button @click="cerrarModalEdicion" class="btn-close">
          <i class="ph ph-x"></i>
        </button>
      </div>
      
      <div class="modal-body">
        <div class="campo-formulario">
          <label class="form-label">Comentario / Descripción</label>
          <textarea v-model="modalEdicion.descripcion" 
                    class="form-input" 
                    rows="3"
                    placeholder="Agregue un comentario sobre esta evidencia...">
          </textarea>
        </div>
        
        <div class="campo-formulario">
          <label class="form-label">Fecha de vigencia (opcional)</label>
          <input v-model="modalEdicion.fechaVigencia" 
                 type="date" 
                 class="form-input">
        </div>
      </div>

      <div class="modal-footer">
        <button @click="cerrarModalEdicion" class="btn btn-secondary">Cancelar</button>
        <button @click="guardarEdicionEvidencia" class="btn btn-primary">
          Guardar Cambios
        </button>
      </div>
    </div>
  </div>

  <!-- Modal de Visualización de Archivo -->
  <div v-if="modalVisualizacion.visible" class="modal-overlay" @click="cerrarModalVisualizacion">
    <div class="modal-content modal-lg" @click.stop>
      <div class="modal-header">
        <h3>{{ modalVisualizacion.archivo?.nombre }}</h3>
        <div class="modal-header-actions">
          <button @click="descargarArchivo(modalVisualizacion.archivo)" class="btn btn-secondary btn-sm">
            <i class="ph ph-download"></i> Descargar
          </button>
          <button @click="cerrarModalVisualizacion" class="btn-close">
            <i class="ph ph-x"></i>
          </button>
        </div>
      </div>
      
      <div class="modal-body">
        <!-- Vista previa según tipo de archivo -->
        <div v-if="esImagen(modalVisualizacion.archivo?.nombre)" class="preview-container">
          <img :src="modalVisualizacion.url" alt="Vista previa" class="preview-image">
        </div>
        
        <div v-else-if="esPDF(modalVisualizacion.archivo?.nombre)" class="preview-container">
          <iframe :src="modalVisualizacion.url" class="preview-pdf"></iframe>
        </div>
        
        <div v-else class="preview-no-disponible">
          <i class="ph ph-file-text" style="font-size: 4rem; color: #60a5fa;"></i>
          <p>Vista previa no disponible para este tipo de archivo</p>
          <p class="text-sm">{{ modalVisualizacion.archivo?.nombre }}</p>
        </div>
        
        <!-- Información del archivo -->
        <div class="archivo-info-detail">
          <div class="info-row">
            <span class="info-label">Tipo:</span>
            <span>{{ obtenerExtension(modalVisualizacion.archivo?.nombre) }}</span>
          </div>
          <div class="info-row" v-if="modalVisualizacion.archivo?.descripcion">
            <span class="info-label">Descripción:</span>
            <span>{{ modalVisualizacion.archivo.descripcion }}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Fecha de carga:</span>
            <span>{{ modalVisualizacion.archivo?.fechaSubida || 'No especificada' }}</span>
          </div>
          <div class="info-row" v-if="modalVisualizacion.archivo?.fechaVigencia">
            <span class="info-label">Vigente hasta:</span>
            <span>{{ formatearFecha(modalVisualizacion.archivo.fechaVigencia) }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import apiClient from '../services/api.js'

// Props
const props = defineProps({
  incidenteId: { type: [Number, String], default: null },
  modo: { type: String, default: 'creacion' },
  empresaId: { type: [Number, String], required: true }
})

// Router
const router = useRouter()
const route = useRoute()

// Estado
const loading = ref(false)
const error = ref(null)
const guardando = ref(false)
const acordeonesAbiertos = reactive(new Set(['identificacion']))

// Información de la empresa
const empresaInfo = ref({
  nombre: '',
  tipo: ''
})

// Datos del incidente
const datos = reactive({
  tipoFlujo: 'Informativo',
  titulo: '',
  fechaDeteccion: '',
  fechaOcurrencia: '',
  criticidad: 'Media',
  alcanceGeografico: 'Local',
  descripcionInicial: '',
  impactoPreliminar: '',
  sistemasAfectados: '',
  serviciosInterrumpidos: '',
  tipoAmenaza: '',
  vectorAtaque: '',
  responsableCliente: '',
  medidasContencion: '',
  analisisCausaRaiz: '',
  leccionesAprendidas: '',
  recomendacionesMejora: '',
  taxonomiasSeleccionadas: [],
  evidencias: {
    descripcion: [],
    analisis: [],
    acciones: [],
    'analisis-final': []
  }
})

// Taxonomías
const taxonomiaSeleccionada = ref('')
const taxonomiaActiva = ref(null)
const taxonomiasDisponibles = ref([])
const datosTaxonomias = reactive({})

// Modal de evidencias
const modalEvidencias = reactive({
  visible: false,
  seccion: null
})
const archivosTemporales = ref([])

// Modal de edición
const modalEdicion = reactive({
  visible: false,
  archivo: null,
  seccion: null,
  descripcion: '',
  fechaVigencia: ''
})

// Modal de visualización
const modalVisualizacion = reactive({
  visible: false,
  archivo: null,
  url: null
})

// Computed
const esValido = computed(() => {
  return datos.titulo && 
         datos.fechaDeteccion && 
         datos.criticidad && 
         datos.descripcionInicial && 
         datos.sistemasAfectados
})

const todosLosArchivos = computed(() => {
  const archivos = []
  const secciones = {
    'descripcion': 'Descripción y Alcance',
    'analisis': 'Análisis Preliminar',
    'acciones': 'Acciones Inmediatas',
    'analisis-final': 'Análisis Final'
  }
  
  for (const [seccion, nombreSeccion] of Object.entries(secciones)) {
    if (datos.evidencias[seccion]) {
      datos.evidencias[seccion].forEach(archivo => {
        archivos.push({
          ...archivo,
          seccion: nombreSeccion
        })
      })
    }
  }
  
  return archivos
})

// Métodos
function toggleAcordeon(seccion) {
  if (acordeonesAbiertos.has(seccion)) {
    acordeonesAbiertos.delete(seccion)
  } else {
    acordeonesAbiertos.add(seccion)
  }
}

function volverAEmpresas() {
  router.push(`/admin/empresas/${props.empresaId}`)
}

async function cargarDatosEmpresa() {
  try {
    const response = await apiClient.get(`/admin/empresas/${props.empresaId}`)
    empresaInfo.value = {
      nombre: response.data.nombre,
      tipo: response.data.tipo_empresa
    }
  } catch (err) {
    console.error('Error al cargar datos de empresa:', err)
  }
}

async function cargarTaxonomias() {
  try {
    const response = await apiClient.get('/admin/taxonomias')
    taxonomiasDisponibles.value = response.data
  } catch (err) {
    console.error('Error al cargar taxonomías:', err)
  }
}

function agregarTaxonomia() {
  if (!taxonomiaSeleccionada.value) return
  
  const taxonomia = taxonomiasDisponibles.value.find(t => t.Id_Taxonomia === parseInt(taxonomiaSeleccionada.value))
  if (taxonomia && !estaSeleccionada(taxonomia.Id_Taxonomia)) {
    const nuevaTaxonomia = {
      id: taxonomia.Id_Taxonomia,
      nombre: taxonomia.Nombre,
      data: taxonomia
    }
    datos.taxonomiasSeleccionadas.push(nuevaTaxonomia)
    
    // Inicializar datos de la taxonomía
    datosTaxonomias[taxonomia.Id_Taxonomia] = {
      observacionesTecnicas: '',
      observacionesImpacto: ''
    }
    
    // Seleccionar automáticamente la nueva taxonomía
    taxonomiaActiva.value = taxonomia.Id_Taxonomia
  }
  
  taxonomiaSeleccionada.value = ''
}

function estaSeleccionada(idTaxonomia) {
  return datos.taxonomiasSeleccionadas.some(t => t.id === idTaxonomia)
}

function seleccionarTaxonomia(idTaxonomia) {
  taxonomiaActiva.value = taxonomiaActiva.value === idTaxonomia ? null : idTaxonomia
}

function removerTaxonomia(index) {
  const taxonomia = datos.taxonomiasSeleccionadas[index]
  datos.taxonomiasSeleccionadas.splice(index, 1)
  
  // Limpiar datos de la taxonomía
  delete datosTaxonomias[taxonomia.id]
  
  // Si era la taxonomía activa, limpiar selección
  if (taxonomiaActiva.value === taxonomia.id) {
    taxonomiaActiva.value = null
  }
}

function getTaxonomiaSeleccionada() {
  const tax = datos.taxonomiasSeleccionadas.find(t => t.id === taxonomiaActiva.value)
  return tax ? tax.data : null
}

function getTaxonomiaData(idTaxonomia) {
  if (!datosTaxonomias[idTaxonomia]) {
    datosTaxonomias[idTaxonomia] = {
      observacionesTecnicas: '',
      observacionesImpacto: ''
    }
  }
  return datosTaxonomias[idTaxonomia]
}

// Gestión de evidencias
function abrirModalEvidencias(seccion) {
  modalEvidencias.seccion = seccion
  modalEvidencias.visible = true
  archivosTemporales.value = []
}

function cerrarModalEvidencias() {
  modalEvidencias.visible = false
  modalEvidencias.seccion = null
  archivosTemporales.value = []
}

function handleFileUpload(event) {
  const files = Array.from(event.target.files)
  files.forEach(file => {
    archivosTemporales.value.push({
      file: file,
      name: file.name,
      descripcion: ''
    })
  })
}

function removerArchivoTemporal(index) {
  archivosTemporales.value.splice(index, 1)
}

function guardarEvidencias() {
  // Agregar archivos temporales a la sección correspondiente
  archivosTemporales.value.forEach(archivo => {
    datos.evidencias[modalEvidencias.seccion].push({
      nombre: archivo.name,
      descripcion: archivo.descripcion,
      fechaSubida: new Date().toLocaleString(),
      file: archivo.file
    })
  })
  
  cerrarModalEvidencias()
}

function getEvidencias(seccion) {
  return datos.evidencias[seccion] || []
}

function eliminarEvidencia(seccion, index) {
  if (confirm('¿Está seguro de eliminar esta evidencia?')) {
    datos.evidencias[seccion].splice(index, 1)
  }
}

function verEvidencia(archivo) {
  modalVisualizacion.archivo = archivo
  modalVisualizacion.visible = true
  
  // Si es un archivo local (recién subido), crear URL temporal
  if (archivo.file) {
    modalVisualizacion.url = URL.createObjectURL(archivo.file)
  } else {
    // Si es un archivo del servidor, usar la URL del servidor
    modalVisualizacion.url = archivo.url || '#'
  }
}

function cerrarModalVisualizacion() {
  modalVisualizacion.visible = false
  modalVisualizacion.archivo = null
  if (modalVisualizacion.url && modalVisualizacion.url.startsWith('blob:')) {
    URL.revokeObjectURL(modalVisualizacion.url)
  }
  modalVisualizacion.url = null
}

function descargarArchivo(archivo) {
  if (archivo.file) {
    // Si es un archivo local, crear un enlace temporal
    const url = URL.createObjectURL(archivo.file)
    const a = document.createElement('a')
    a.href = url
    a.download = archivo.nombre
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  } else if (archivo.url) {
    // Si es del servidor, abrir en nueva pestaña
    window.open(archivo.url, '_blank')
  }
}

function getNombreSeccion(seccion) {
  const nombres = {
    'descripcion': 'Descripción y Alcance',
    'analisis': 'Análisis Preliminar',
    'acciones': 'Acciones Inmediatas',
    'analisis-final': 'Análisis Final'
  }
  return nombres[seccion] || seccion
}

function getIconoArchivo(nombreArchivo) {
  const extension = nombreArchivo.split('.').pop().toLowerCase()
  const iconos = {
    'pdf': 'ph ph-file-pdf',
    'doc': 'ph ph-file-doc',
    'docx': 'ph ph-file-doc',
    'xls': 'ph ph-file-xls',
    'xlsx': 'ph ph-file-xls',
    'ppt': 'ph ph-file-ppt',
    'pptx': 'ph ph-file-ppt',
    'png': 'ph ph-file-image',
    'jpg': 'ph ph-file-image',
    'jpeg': 'ph ph-file-image',
    'gif': 'ph ph-file-image',
    'zip': 'ph ph-file-zip',
    'rar': 'ph ph-file-zip'
  }
  return iconos[extension] || 'ph ph-file'
}

function editarEvidencia(archivo, seccion) {
  modalEdicion.archivo = archivo
  modalEdicion.seccion = seccion
  modalEdicion.descripcion = archivo.descripcion || ''
  modalEdicion.fechaVigencia = archivo.fechaVigencia || ''
  modalEdicion.visible = true
}

function cerrarModalEdicion() {
  modalEdicion.visible = false
  modalEdicion.archivo = null
  modalEdicion.seccion = null
  modalEdicion.descripcion = ''
  modalEdicion.fechaVigencia = ''
}

function guardarEdicionEvidencia() {
  if (modalEdicion.archivo) {
    modalEdicion.archivo.descripcion = modalEdicion.descripcion
    modalEdicion.archivo.fechaVigencia = modalEdicion.fechaVigencia
  }
  cerrarModalEdicion()
}

function esImagen(nombreArchivo) {
  if (!nombreArchivo) return false
  const ext = nombreArchivo.split('.').pop().toLowerCase()
  return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)
}

function esPDF(nombreArchivo) {
  if (!nombreArchivo) return false
  const ext = nombreArchivo.split('.').pop().toLowerCase()
  return ext === 'pdf'
}

function obtenerExtension(nombreArchivo) {
  if (!nombreArchivo) return 'Desconocido'
  return nombreArchivo.split('.').pop().toUpperCase()
}

function formatearFecha(fecha) {
  if (!fecha) return ''
  const opciones = { year: 'numeric', month: 'long', day: 'numeric' }
  return new Date(fecha).toLocaleDateString('es-ES', opciones)
}

async function guardarIncidente() {
  if (!esValido.value) {
    alert('Por favor complete todos los campos obligatorios')
    return
  }
  
  guardando.value = true
  error.value = null
  
  try {
    // Preparar datos para enviar
    const datosIncidente = {
      empresa_id: props.empresaId,
      tipo_flujo: datos.tipoFlujo,
      titulo: datos.titulo,
      fecha_deteccion: datos.fechaDeteccion,
      fecha_ocurrencia: datos.fechaOcurrencia || datos.fechaDeteccion,
      criticidad: datos.criticidad,
      alcance_geografico: datos.alcanceGeografico,
      descripcion_inicial: datos.descripcionInicial,
      impacto_preliminar: datos.impactoPreliminar,
      sistemas_afectados: datos.sistemasAfectados,
      servicios_interrumpidos: datos.serviciosInterrumpidos,
      tipo_amenaza: datos.tipoAmenaza,
      vector_ataque: datos.vectorAtaque,
      responsable_cliente: datos.responsableCliente,
      medidas_contencion: datos.medidasContencion,
      analisis_causa_raiz: datos.analisisCausaRaiz,
      lecciones_aprendidas: datos.leccionesAprendidas,
      recomendaciones_mejora: datos.recomendacionesMejora,
      taxonomias: datos.taxonomiasSeleccionadas.map(t => ({
        id: t.id,
        observaciones_tecnicas: datosTaxonomias[t.id]?.observacionesTecnicas || '',
        observaciones_impacto: datosTaxonomias[t.id]?.observacionesImpacto || ''
      }))
    }
    
    let response
    if (props.modo === 'edicion' && props.incidenteId) {
      response = await apiClient.put(`/admin/incidentes/${props.incidenteId}`, datosIncidente)
    } else {
      response = await apiClient.post('/admin/incidentes', datosIncidente)
    }
    
    // Subir evidencias si hay nuevas
    for (const [seccion, archivos] of Object.entries(datos.evidencias)) {
      for (const archivo of archivos) {
        if (archivo.file) {
          const formData = new FormData()
          formData.append('archivo', archivo.file)
          formData.append('descripcion', archivo.descripcion)
          formData.append('seccion', seccion)
          
          await apiClient.post(`/admin/incidentes/${response.data.id}/evidencias`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
          })
        }
      }
    }
    
    alert('Incidente guardado exitosamente')
    router.push(`/admin/empresas/${props.empresaId}`)
  } catch (err) {
    console.error('Error al guardar incidente:', err)
    error.value = err.response?.data?.error || 'Error al guardar el incidente'
  } finally {
    guardando.value = false
  }
}

// Cargar datos al montar
onMounted(() => {
  cargarDatosEmpresa()
  cargarTaxonomias()
  
  // Si es modo edición, cargar datos del incidente
  if (props.modo === 'edicion' && props.incidenteId) {
    // Implementar carga de datos del incidente
  }
})
</script>

<style scoped>
/* Estilos base del card-dark */
.card-dark {
  background-color: #1a1d23;
  border-radius: 0.5rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

/* Header con navegación */
.header-con-navegacion {
  background-color: #111318;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  border-bottom: 1px solid #2d3748;
}

.empresa-info-header {
  font-size: 0.875rem;
  color: #9ca3af;
  font-weight: normal;
}

/* Botón volver */
.btn-volver {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background-color: #2d3748;
  color: #e5e7eb;
  border: none;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-volver:hover {
  background-color: #374151;
  color: #ffffff;
}

/* Acordeón */
.accordion-item {
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.5rem;
  overflow: hidden;
}

.accordion-header {
  width: 100%;
  padding: 1rem 1.5rem;
  background-color: #1f2937;
  border: none;
  color: #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: background-color 0.2s;
}

.accordion-header:hover {
  background-color: #2d3748;
}

.header-text {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex: 1;
}

.accordion-icon {
  font-size: 1.25rem;
  color: #60a5fa;
}

.section-title-accordion {
  font-size: 1rem;
  font-weight: 600;
}

.accordion-caret {
  font-size: 1.25rem;
  transition: transform 0.3s;
}

.accordion-caret.open {
  transform: rotate(180deg);
}

.accordion-content {
  padding: 1.5rem;
  background-color: #111318;
  border-top: 1px solid #374151;
}

/* Transición del acordeón */
.accordion-fade-enter-active,
.accordion-fade-leave-active {
  transition: all 0.3s ease;
  max-height: 2000px;
  overflow: hidden;
}

.accordion-fade-enter-from,
.accordion-fade-leave-to {
  max-height: 0;
  opacity: 0;
  padding-top: 0;
  padding-bottom: 0;
}

/* Secciones de contenido */
.content-section {
  margin-bottom: 1.5rem;
}

.content-section:last-child {
  margin-bottom: 0;
}

.section-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: #e5e7eb;
  margin-bottom: 1rem;
}

/* Formularios */
.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}

.campo-formulario {
  margin-bottom: 1rem;
}

.form-label {
  display: block;
  margin-bottom: 0.5rem;
  color: #9ca3af;
  font-size: 0.875rem;
  font-weight: 500;
}

.form-input {
  width: 100%;
  padding: 0.5rem 0.75rem;
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.375rem;
  color: #e5e7eb;
  font-size: 0.875rem;
  transition: all 0.2s;
}

.form-input:focus {
  outline: none;
  border-color: #60a5fa;
  box-shadow: 0 0 0 1px #60a5fa;
}

.form-input::placeholder {
  color: #6b7280;
}

select.form-input {
  cursor: pointer;
}

textarea.form-input {
  resize: vertical;
  min-height: 80px;
}

/* Evidencias */
.evidencias-full-width {
  width: 100%;
}

.evidencias-box {
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.5rem;
  overflow: hidden;
}

.evidencias-header {
  padding: 1rem;
  background-color: #111318;
  border-bottom: 1px solid #374151;
}

.evidencias-header h3 {
  font-size: 0.875rem;
  font-weight: 600;
  color: #e5e7eb;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.evidencias-stats {
  display: flex;
  gap: 0.5rem;
}

.stat-badge {
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  font-size: 0.75rem;
  font-weight: 500;
}

.stat-badge.vigente {
  background-color: #10b981;
  color: white;
}

.evidencias-list {
  padding: 0.5rem;
}

.evidencia-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem;
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.375rem;
  margin-bottom: 0.5rem;
  transition: all 0.2s;
}

.evidencia-item:hover {
  background-color: #2d3748;
  border-color: #4b5563;
}

.evidencia-content {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
  cursor: pointer;
}

.evidencia-info {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex: 1;
}

.evidencia-icon {
  font-size: 1.5rem;
  color: #60a5fa;
}

.evidencia-details {
  flex: 1;
}

.evidencia-name-line {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 0.875rem;
}

.evidencia-name {
  font-weight: 500;
  color: #e5e7eb;
}

.evidencia-version {
  color: #6b7280;
  font-size: 0.75rem;
}

.evidencia-comentario {
  color: #9ca3af;
  font-style: italic;
  font-size: 0.75rem;
}

.evidencia-actions {
  display: flex;
  gap: 0.5rem;
}

.btn-editar-evidencia {
  padding: 0.25rem 0.5rem;
  background-color: #3b82f6;
  color: white;
  border: none;
  border-radius: 0.25rem;
  font-size: 0.75rem;
  cursor: pointer;
  transition: background-color 0.2s;
  margin-right: 0.25rem;
}

.btn-editar-evidencia:hover {
  background-color: #2563eb;
}

.btn-eliminar-evidencia {
  padding: 0.25rem 0.5rem;
  background-color: #ef4444;
  color: white;
  border: none;
  border-radius: 0.25rem;
  font-size: 0.75rem;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-eliminar-evidencia:hover {
  background-color: #dc2626;
}

.evidencias-empty {
  padding: 2rem;
  text-align: center;
  color: #6b7280;
  font-size: 0.875rem;
}

.evidencias-footer {
  padding: 1rem;
  background-color: #111318;
  border-top: 1px solid #374151;
  text-align: center;
}

.evidencias-footer button {
  color: #60a5fa;
  background: none;
  border: none;
  font-size: 0.875rem;
  cursor: pointer;
  transition: color 0.2s;
}

.evidencias-footer button:hover {
  color: #93bbfc;
  text-decoration: underline;
}

/* Taxonomías */
.taxonomias-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.taxonomy-chip {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 0.75rem;
  background-color: #2d3748;
  border: 1px solid #4b5563;
  border-radius: 0.375rem;
  color: #e5e7eb;
  font-size: 0.875rem;
  cursor: pointer;
  transition: all 0.2s;
}

.taxonomy-chip:hover {
  background-color: #374151;
  border-color: #6b7280;
}

.taxonomy-chip.active {
  background-color: #1e40af;
  border-color: #3b82f6;
}

.chip-remove {
  background: none;
  border: none;
  color: #9ca3af;
  cursor: pointer;
  padding: 0;
  font-size: 1rem;
  transition: color 0.2s;
}

.chip-remove:hover {
  color: #ef4444;
}

.taxonomia-detalle {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
}

.taxonomia-campo {
  display: flex;
  gap: 0.5rem;
}

.taxonomia-label {
  font-weight: 600;
  color: #9ca3af;
}

.taxonomia-valor {
  color: #e5e7eb;
}

/* Botones de acción */
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid #374151;
}

.btn {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-primary {
  background-color: #3b82f6;
  color: white;
}

.btn-primary:hover:not(:disabled) {
  background-color: #2563eb;
}

.btn-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-secondary {
  background-color: #4b5563;
  color: #e5e7eb;
}

.btn-secondary:hover {
  background-color: #6b7280;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: #1a1d23;
  border-radius: 0.5rem;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem;
  background-color: #111318;
  border-bottom: 1px solid #374151;
}

.modal-header h3 {
  font-size: 1.125rem;
  font-weight: 600;
  color: #e5e7eb;
  margin: 0;
}

.btn-close {
  background: none;
  border: none;
  color: #9ca3af;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0.25rem;
  transition: color 0.2s;
}

.btn-close:hover {
  color: #e5e7eb;
}

.modal-body {
  padding: 1.5rem;
  overflow-y: auto;
  flex: 1;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  padding: 1.5rem;
  background-color: #111318;
  border-top: 1px solid #374151;
}

/* Upload zone */
.upload-zone {
  margin-bottom: 1.5rem;
}

.upload-drop-zone {
  border: 2px dashed #374151;
  border-radius: 0.5rem;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
}

.upload-drop-zone:hover {
  border-color: #60a5fa;
  background-color: rgba(96, 165, 250, 0.05);
}

.upload-drop-zone i {
  font-size: 3rem;
  color: #60a5fa;
  margin-bottom: 0.5rem;
}

.upload-drop-zone p {
  color: #9ca3af;
  margin: 0.25rem 0;
}

.upload-drop-zone .text-sm {
  font-size: 0.875rem;
  color: #6b7280;
}

/* Archivos temporales */
.archivos-temporales {
  margin-bottom: 1.5rem;
}

.archivos-temporales h4 {
  font-size: 0.875rem;
  font-weight: 600;
  color: #e5e7eb;
  margin-bottom: 0.75rem;
}

.archivo-temporal {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.375rem;
  margin-bottom: 0.5rem;
}

.archivo-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #e5e7eb;
  font-size: 0.875rem;
}

.btn-remove {
  background-color: #ef4444;
  color: white;
  border: none;
  border-radius: 0.25rem;
  padding: 0.25rem 0.5rem;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-remove:hover {
  background-color: #dc2626;
}

/* Evidencias existentes en modal */
.evidencias-existentes {
  margin-top: 1.5rem;
}

.evidencias-existentes h4 {
  font-size: 0.875rem;
  font-weight: 600;
  color: #e5e7eb;
  margin-bottom: 0.75rem;
}

.evidencia-item-modal {
  padding: 0.75rem;
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.375rem;
  margin-bottom: 0.5rem;
}

.evidencia-fecha {
  color: #6b7280;
  font-size: 0.75rem;
  margin-left: 0.5rem;
}

.evidencia-descripcion {
  margin: 0.5rem 0;
  color: #9ca3af;
  font-size: 0.875rem;
  font-style: italic;
}

.btn-eliminar {
  background-color: #ef4444;
  color: white;
  border: none;
  border-radius: 0.25rem;
  padding: 0.25rem 0.75rem;
  font-size: 0.875rem;
  cursor: pointer;
  transition: background-color 0.2s;
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
}

.btn-eliminar:hover {
  background-color: #dc2626;
}

/* Resumen de archivos */
.archivos-resumen-container {
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.5rem;
  overflow: hidden;
}

.archivos-stats-global {
  padding: 1rem;
  background-color: #111318;
  border-bottom: 1px solid #374151;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #e5e7eb;
  font-size: 0.875rem;
}

.archivos-table {
  width: 100%;
  border-collapse: collapse;
}

.archivos-table th {
  text-align: left;
  padding: 0.75rem;
  background-color: #111318;
  color: #9ca3af;
  font-weight: 600;
  font-size: 0.875rem;
  border-bottom: 1px solid #374151;
}

.archivos-table td {
  padding: 0.75rem;
  color: #e5e7eb;
  font-size: 0.875rem;
  border-bottom: 1px solid #374151;
}

.archivos-table tr:hover td {
  background-color: #2d3748;
}

.btn-action {
  background: none;
  border: none;
  color: #60a5fa;
  font-size: 1rem;
  cursor: pointer;
  padding: 0.25rem;
  transition: color 0.2s;
}

.btn-action:hover {
  color: #93bbfc;
}

/* Animación de spinner */
.animate-spin {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* Error banner */
.error-banner {
  background-color: #7f1d1d;
  color: #fca5a5;
  padding: 1rem;
  border-radius: 0.375rem;
  margin: 1rem;
}

/* Modales pequeño y grande */
.modal-sm {
  max-width: 400px;
}

.modal-lg {
  max-width: 900px;
}

/* Modal header con acciones */
.modal-header-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-sm {
  padding: 0.375rem 0.75rem;
  font-size: 0.75rem;
}

/* Contenedor de vista previa */
.preview-container {
  background-color: #111318;
  border-radius: 0.5rem;
  padding: 1rem;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 400px;
}

.preview-image {
  max-width: 100%;
  max-height: 500px;
  object-fit: contain;
  border-radius: 0.375rem;
}

.preview-pdf {
  width: 100%;
  height: 500px;
  border: none;
  border-radius: 0.375rem;
}

.preview-no-disponible {
  text-align: center;
  padding: 3rem;
  color: #9ca3af;
}

.preview-no-disponible p {
  margin-top: 1rem;
}

.preview-no-disponible .text-sm {
  font-size: 0.875rem;
  color: #6b7280;
  margin-top: 0.5rem;
}

/* Información detallada del archivo */
.archivo-info-detail {
  background-color: #1f2937;
  border: 1px solid #374151;
  border-radius: 0.5rem;
  padding: 1rem;
  margin-top: 1rem;
}

.info-row {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 0.5rem 0;
  border-bottom: 1px solid #374151;
}

.info-row:last-child {
  border-bottom: none;
}

.info-label {
  font-weight: 600;
  color: #9ca3af;
  min-width: 120px;
}

/* Campo de fecha en modal */
.campo-formulario input[type="date"] {
  cursor: pointer;
}
</style>